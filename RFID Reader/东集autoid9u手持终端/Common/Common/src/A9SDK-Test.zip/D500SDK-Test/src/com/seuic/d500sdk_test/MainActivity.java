package com.seuic.d500sdk_test;

import com.seuic.touch.TouchService;
import com.seuic.keypad.KeypadService;
import com.seuic.misc.Misc;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
	/*
	 * Initialize the key service object
	 */
	private KeypadService keypad = KeypadService.getInstance();
	/*
	 * Initialize the touch screen service object
	 */
	private TouchService touch = TouchService.getInstance();
	/*
	 * Initialize the Misc object
	 */
	private Misc misc = new Misc();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected void onResume() {
		/*
		 * Get the device serial number
		 */
		String strDeviceId = misc.getSN();
		TextView textID = (TextView)this.findViewById(R.id.textDeviceId);
		textID.setText(strDeviceId);
		
		/*
		 * According to the actual state of the device to restore the button state If you do not support this function, the button is ashed
		 */
		Switch btnKeypadMode = (Switch) this
				.findViewById(R.id.toggleKeypadMode);
		int keypadMode = keypad.getMode();
		if (keypadMode < 0) {
			btnKeypadMode.setEnabled(false);
		} else if (keypadMode == KeypadService.MODE_STICK_ONCE) {
			btnKeypadMode.setChecked(true);
		}

		Switch btnTouchLocked = (Switch) this
				.findViewById(R.id.toggleTouchLocked);
		int touchEnabled = touch.getTouchEnabled();
		if (touchEnabled < 0) {
			btnTouchLocked.setEnabled(false);
		} else if (touchEnabled == TouchService.TOUCH_ENABLED_ON) {
			btnTouchLocked.setChecked(true);
		}

		int[] vkeys = { R.id.toggleVKey1Disabled, R.id.toggleVKey2Disabled };
		int[] masks = { TouchService.VKEY1_DISABLE_MASK,
				TouchService.VKEY2_DISABLE_MASK };
		for (int i = 0; i < 2; i++) {
			Switch btnVKeyDisabled = (Switch) this.findViewById(vkeys[i]);
			int vkeyDisabled = touch.getVirKeyDisabled();
			if (vkeyDisabled < 0) {
				btnVKeyDisabled.setEnabled(false);
			} else if ((vkeyDisabled & masks[i]) != 0) {
				btnVKeyDisabled.setChecked(true);
			}
		}

		Switch btnStatusBarEnabled = (Switch) this
				.findViewById(R.id.toggleStatusBarDisabled);
		int statusbarEnabled = misc.getStatusBarEnabled(this);
		if (statusbarEnabled < 0) {
			btnStatusBarEnabled.setEnabled(false);
		} else if (statusbarEnabled == Misc.STATUSBAR_DISABLED) {
			btnStatusBarEnabled.setChecked(true);
		}
		
		Switch btnExtSDCardUnmounted = (Switch) this
				.findViewById(R.id.toggleUnmountExtSD);
		int extSDCardUnmounted = misc.getExtSDCardMounted(this);
		if (extSDCardUnmounted < 0) {
			btnExtSDCardUnmounted.setEnabled(false);
		} else if (extSDCardUnmounted == Misc.EXT_SDCARD_UNMOUNTED) {
			btnExtSDCardUnmounted.setChecked(true);
		}

		super.onResume();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		/*
		 * After the lock screen touch can not use, this time can be switched by F10
		 */
		if (keyCode == KeyEvent.KEYCODE_F10) {
			Switch btnTouchLocked = (Switch) this
					.findViewById(R.id.toggleTouchLocked);
			if (touch.getTouchEnabled() == TouchService.TOUCH_ENABLED_ON) {
				touch.setTouchEnabled(TouchService.TOUCH_ENABLED_OFF, this);
				btnTouchLocked.setChecked(false);
			} else {
				touch.setTouchEnabled(TouchService.TOUCH_ENABLED_ON, this);
				btnTouchLocked.setChecked(true);
			}

		}
		return super.onKeyDown(keyCode, event);
	}

	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.toggleKeypadMode:
			if (keypad.getMode() == KeypadService.MODE_NORMAL)
				keypad.setMode(KeypadService.MODE_STICK_ONCE);
			else
				keypad.setMode(KeypadService.MODE_NORMAL);
			break;

		case R.id.toggleTouchLocked:
			if (touch.getTouchEnabled() == TouchService.TOUCH_ENABLED_ON)
				touch.setTouchEnabled(TouchService.TOUCH_ENABLED_OFF, this);
			else
				touch.setTouchEnabled(TouchService.TOUCH_ENABLED_ON, this);
			break;

		case R.id.toggleVKey1Disabled:
			int vkeyDisabled = touch.getVirKeyDisabled();
			if ((vkeyDisabled & TouchService.VKEY1_DISABLE_MASK) != 0) {
				vkeyDisabled &= ~TouchService.VKEY1_DISABLE_MASK;
				touch.setVirKeyDisabled(vkeyDisabled);
			} else {
				vkeyDisabled |= TouchService.VKEY1_DISABLE_MASK;
				touch.setVirKeyDisabled(vkeyDisabled);
			}
			break;

		case R.id.toggleVKey2Disabled:
			vkeyDisabled = touch.getVirKeyDisabled();
			if ((vkeyDisabled & TouchService.VKEY2_DISABLE_MASK) != 0) {
				vkeyDisabled &= ~TouchService.VKEY2_DISABLE_MASK;
				touch.setVirKeyDisabled(vkeyDisabled);
			} else {
				vkeyDisabled |= TouchService.VKEY2_DISABLE_MASK;
				touch.setVirKeyDisabled(vkeyDisabled);
			}
			break;

		case R.id.toggleStatusBarDisabled:
			int statusbarEnabled = misc.getStatusBarEnabled(this);
			if (statusbarEnabled == Misc.STATUSBAR_ENABLED)
				misc.setStatusBarEnabled(this, Misc.STATUSBAR_DISABLED);
			else
				misc.setStatusBarEnabled(this, Misc.STATUSBAR_ENABLED);
			break;

		case R.id.toggleUnmountExtSD:
			int extSDCardUnmounted = misc.getExtSDCardMounted(this);
			if (extSDCardUnmounted == Misc.EXT_SDCARD_MOUNTED)
				misc.setExtSDCardMounted(this, Misc.EXT_SDCARD_UNMOUNTED);
			else
				misc.setExtSDCardMounted(this, Misc.EXT_SDCARD_MOUNTED);
			break;
		}

	}
}
